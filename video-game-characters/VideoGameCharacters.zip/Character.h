/*
 * Character.h
 *
 *  Created on: Mar 30, 2019
 *      Author: Markus Walker
 */

#ifndef CHARACTER_H_
#define CHARACTER_H_
#include <string>

class Character {
public:
	void characterName(std::string name);
	void firstApperance(std::string debut);
	void famousQuote(std::string quote);

	Character();
	~Character();
};

#endif /* CHARACTER_H_ */
