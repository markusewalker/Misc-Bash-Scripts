-----------------------------------
Project Name: Video Game Characters
-----------------------------------
Purpose:
	To illustrate Object Oriented Programming concepts through listing iconic video game characters and their first apperances / famous quotes.


Originally developed on Eclipse IDE for C/C++ Developers and then ported to Linux distro Ubuntu.

Completed and tested on March 30th, 2019.

------------------------
Brief Usage Instructions
------------------------
Compiling:
	g++ -Wall -g --std=c++14 Character.cpp
	g++ -Wall -g --std=c++14 main.cpp
Linking:
	g++ Character.cpp main.cpp -o VideoGameCharacters
