/*
File Name:     main.cpp
Original Date: Mar 30, 2019
Authored By:   Markus Walker

Description: Lists few iconic video game characters along with their first appearances and a famous quote.
			 This simple program utilizes Object Oriented Programming concepts such as abstraction and
			 encapsulation
*/
#include <iostream>
#include <string>
#include "Character.h"


int main() {
	std::cout << "===============================================" << std::endl;
	std::cout << "\tIconic Video Game Characters" << std::endl;
	std::cout << "===============================================" << std::endl;
	std::cout << "This program lists some of video games most iconic characters, their first apperances and a famous quote!" << std::endl;
	std::cout << std::endl;

	Character sonic{};
	sonic.characterName("Sonic The Hedgehog");
	sonic.firstApperance("Rad Mobile: 1991");
	sonic.famousQuote("Way Past Cool!");
	std::cout <<"------------------------------------------------------------------------------------" << std::endl;
	
	Character mario{};
	mario.characterName("Mario");
	mario.firstApperance("Donkey Kong: 1981");
	mario.famousQuote("It's-a me, Mario!");
	std::cout <<"------------------------------------------------------------------------------------" << std::endl;

	Character link{};
	link.characterName("Link");
	link.firstApperance("The Legend of Zelda: 1986");
	link.famousQuote("It's dangerous to go alone! Take this!");

	return 0;
}
