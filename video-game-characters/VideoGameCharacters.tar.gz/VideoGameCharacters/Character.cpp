/*
File Name:     Character.cpp
Original Date: Mar 30, 2019
Authored By:   Markus Walker

Description :  Defining the previously declared methods found in Character.h.
*/
#include <iostream>
#include "Character.h"

Character::Character() {
}

Character::~Character(){
}

void Character::characterName(std::string name) {
	std::cout << "Character's name is: " << name << std::endl;
}

void Character::firstApperance(std::string debut) {
	std::cout << "First appearance was in: " << debut << std::endl;
}

void Character::famousQuote(std::string quote) {
	std::cout << "Famous Quote: " << quote << std::endl;
}
