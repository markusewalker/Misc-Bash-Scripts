-----------------------------------
Project Name: Video Game Characters
-----------------------------------
Purpose:
	To illustrate Object Oriented Programming concepts through listing iconic video game characters and their first apperances / famous quotes.


Originally developed on Eclipse IDE for C/C++ Developers and then ported to Linux distro Ubuntu.

Completed and tested on March 30th, 2019.

------------------------
Brief Usage Instructions
------------------------
Developed in Eclipse IDE for C/C++ Developers. The following GCC flags were utilized:
	-O0 -g3 -Wall -c -fmessage-length=0
	
Should build in other IDEs such as Visual Studio as well, but please note that this has NOT been tested.